rm z1/*~ z1/*.out
rm z2/*~ z2/*.out
rm z3/*~ z3/*.out

