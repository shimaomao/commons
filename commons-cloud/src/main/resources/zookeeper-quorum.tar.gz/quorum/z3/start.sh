/home/zhoujiagen/devtools/zookeeper-3.4.6/bin/zkServer.sh start ./zoo.cfg
